/* For backwards compatibility only.  Packages should start using */
/* LinkingTo: Matrix (>= 1.6-2) and #include <Matrix/stubs.c>.    */
#include "Matrix/alloca.h"
#include "Matrix/remap.h"
#include "Matrix/stubs.c"
